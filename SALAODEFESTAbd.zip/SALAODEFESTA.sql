create database Salaaodefesta;
use Salaaodefesta;

create table if not exists Aluguel(
Id_Aluguel int primary key auto_increment,
	Nome_Cliente varchar(60),
    NBI varchar(20),
    Sexo varchar(20),
    Contacto varchar(15),
    Email varchar(50),
    Data_Evento datetime,
    Outros_Servicos varchar(30),
    Hora_Inicio varchar(10),
    Hora_Termino varchar(10),
    Valor_Total long,
    Status_do_Pagamento varchar(20),
    Forma_de_Pagamento varchar(20),
    Nome_Funcionario varchar(60),
    Data_Cadastro datetime
);

create table if not exists Usuario(
    Id_Usuario int primary key auto_increment,
    Nome varchar(50),
    Senha varchar(100),
    Nivel_acesso varchar(30)
);

Create table Funcionario
(
id_Funcionario int primary key auto_increment,
Nome varchar(50),
Sobrenome varchar (50),
Sexo varchar(15),
Contacto varchar(60)unique,
Endereco varchar(50),
Salario long,
Senha long,
Foto_perfil varchar (100)
);
select * from Funcionario;
Create table Fornecedor
(
id_Fornecedor int primary key auto_increment,
Nome varchar(50),
Sobrenome varchar (50),
Sexo varchar(15),
Contacto varchar(60)unique,
Produto long,
Valor_pago long,
Foto_perfil varchar (100)
);

Create table Ativos
(
id_Ativos int primary key auto_increment,
Nome_Ativo varchar(50),
Quantidade long,
Custo double
);